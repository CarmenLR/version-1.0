vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|25 Nov 2015 01:34:20 -0000
vti_extenderversion:SR|12.0.0.0
vti_author:SR|Medina\\guimea93
vti_modifiedby:SR|Medina\\guimea93
vti_timecreated:TR|25 Nov 2015 01:34:20 -0000
vti_cacheddtm:TX|25 Nov 2015 01:34:20 -0000
vti_filesize:IR|68954
vti_backlinkinfo:VX|Proyectos\\ Bootstrap/Grid/Historia.html Proyectos\\ Bootstrap/Grid/Contacto.html Proyectos\\ Bootstrap/Grid/Menu.html Proyectos\\ Bootstrap/Grid/index.html
